<?php return array (
  'software_id' => '56881320',
  'name' => 'Rental',
  'is_published' => 0,
  'purchase_code' => '',
  'username' => '',
);
