<?php

return [
    'name' => 'Rental'
];
