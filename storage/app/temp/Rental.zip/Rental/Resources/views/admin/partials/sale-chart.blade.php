<div id="grow-sale-chart"></div>
