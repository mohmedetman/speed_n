<?php
echo "<pre>";
echo "PHP Version: " . phpversion() . "\n";
echo "shell_exec: " . (function_exists('shell_exec') ? "enabled" : "disabled") . "\n";
echo "Safe Mode: " . (ini_get('safe_mode') ? "ON" : "OFF") . "\n";
echo "Current User: " . get_current_user() . "\n";
echo "Working Directory: " . getcwd() . "\n";
echo "</pre>";

// Self-delete the script
unlink(__FILE__);
?>
